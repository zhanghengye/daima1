package com.example.administrator.zijixiangmu;

/**
 * Created by Administrator on 2018/5/31.
 */

public class Constants {
    public static final String Web="http://123.57.133.62:8180/lifeshop/";
}
