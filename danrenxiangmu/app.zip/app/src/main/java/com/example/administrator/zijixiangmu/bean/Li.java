package com.example.administrator.zijixiangmu.bean;

/**
 * Created by Administrator on 2018/5/31.
 */

public class Li<T> extends Wai {
    private T data;

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}
