package com.example.administrator.zijixiangmu.base;

import com.example.administrator.zijixiangmu.message.RetrofitMessage;

/**
 * Created by Administrator on 2018/5/30.
 */

 public interface BaseModel {
  public RetrofitMessage mRetrofitManager=new RetrofitMessage();
}
