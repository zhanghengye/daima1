package com.example.administrator.zijixiangmu.base;

/**
 * Created by Administrator on 2018/5/30.
 */

public interface BaseView {
}
