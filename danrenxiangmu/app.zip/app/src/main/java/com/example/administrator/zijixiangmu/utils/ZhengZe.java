package com.example.administrator.zijixiangmu.utils;

/**
 * Created by Administrator on 2018/5/30.
 */

public class ZhengZe {
    public static final String phone="[1][3,5,8,7][0-9]{9}";


}
