package com.example.administrator.zijixiangmu.bean;

/**
 * Created by Administrator on 2018/5/31.
 */

public class Wai {

    /**
     * code : 0
     * data : {}
     * message : string
     */

    private int code;
    private String message;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class DataBean {
    }
}
